<?php 

$settings["database_default_provider"] = "mysql";
$settings["database_default_host"]     = "localhost";
$settings["database_default_username"] = "username";
$settings["database_default_password"] = "password";
$settings["database_default_port"]     = "3306";
$settings["database_default_schema"]   = "prophpmvc";