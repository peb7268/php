<?php if ($filename): ?>
    <img src="/uploads/<?php echo $filename; ?>" />
<?php endif; ?>
<h1><?php echo $user->first; ?> <?php echo $user->last; ?></h1>
This is a profile page!