<?php

namespace Framework\Core\Exception
{
    use Framework\Core as Core;
    
    class ReadOnly extends Core\Exception
    {
        
    }
}