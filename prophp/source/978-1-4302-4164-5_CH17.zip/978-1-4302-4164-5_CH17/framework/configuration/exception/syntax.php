<?php

namespace Framework\Configuration\Exception
{
    use Framework\Configuration as Configuration;
    
    class Syntax extends Configuration\Exception
    {
        
    }
}