<?php

namespace Framework\Router
{
    use Framework\Core as Core;
    
    class Exception extends Core\Exception
    {
        
    }
}