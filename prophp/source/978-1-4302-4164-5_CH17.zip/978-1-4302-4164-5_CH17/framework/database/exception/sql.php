<?php

namespace Framework\Database\Exception
{
    use Framework\Database as Database;
    
    class Sql extends Database\Exception
    {
    
    }
}