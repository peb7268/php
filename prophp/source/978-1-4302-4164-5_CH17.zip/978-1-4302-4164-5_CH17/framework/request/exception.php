<?php

namespace Framework\Request
{
    use Framework\Core as Core;
    
    class Exception extends Core\Exception
    {
    
    }
}