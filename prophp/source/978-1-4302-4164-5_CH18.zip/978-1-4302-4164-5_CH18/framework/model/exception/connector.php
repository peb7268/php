<?php

namespace Framework\Model\Exception
{
    use Framework\Model as Model;
    
    class Connector extends Model\Exception
    {
        
    }
}