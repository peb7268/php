<?php

namespace Framework\Request\Exception
{
    use Framework\Request as Request;
    
    class Response extends Request\Exception
    {
    
    }
}