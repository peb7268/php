<?php

namespace Framework\View\Exception
{
    use Framework\Core as Core;
    
    class Implementation extends Core\Exception\Implementation
    {
        
    }
}