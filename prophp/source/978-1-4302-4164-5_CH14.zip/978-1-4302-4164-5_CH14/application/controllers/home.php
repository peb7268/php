<?php

use Framework\Controller as Controller;

class Home extends Controller
{
    public function index()
    {
        // nothing to see here...
    }
}