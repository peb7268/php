<?php

namespace Framework\Router\Exception
{
    use Framework\Router as Router;
    
    class Controller extends Router\Exception
    {
        
    }
}