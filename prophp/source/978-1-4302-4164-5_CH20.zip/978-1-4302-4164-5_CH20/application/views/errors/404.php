<!DOCTYPE html>
<html>
    <head>
        <title>Social Network</title>
    </head>
    <body>
        error 404
        <?php if (DEBUG): ?>
            <pre><?php print_r($e); ?></pre>
        <?php endif; ?>
    </body>
</html>
