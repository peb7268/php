<?php

namespace Framework\Template\Exception
{
    use Framework\Template as Template;
    
    class Parser extends Template\Exception
    {
    
    }
}