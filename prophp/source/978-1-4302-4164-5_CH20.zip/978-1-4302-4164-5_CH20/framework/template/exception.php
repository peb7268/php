<?php

namespace Framework\Template
{
    use Framework\Core as Core;
    
    class Exception extends Core\Exception
    {
        
    }
}