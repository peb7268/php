<?php

namespace Framework\Model\Exception
{
    use Framework\Model as Model;
    
    class Type extends Model\Exception
    {
        
    }
}