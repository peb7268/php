<?php

namespace Framework\View\Exception
{
    use Framework\View as View;
    
    class Renderer extends View\Exception
    {
        
    }
}