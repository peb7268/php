<?php

namespace Framework\Configuration
{
    use Framework\Core as Core;
    
    class Exception extends Core\Exception
    {
        
    }
}