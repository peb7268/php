<?php

namespace Framework\Core\Exception
{
    use Framework\Core as Core;
    
    class WriteOnly extends Core\Exception
    {
        
    }
}