<?php

namespace Framework\Configuration\Exception
{
    use Framework\Core as Core;
    
    class Argument extends Core\Exception\Argument
    {
        
    }
}