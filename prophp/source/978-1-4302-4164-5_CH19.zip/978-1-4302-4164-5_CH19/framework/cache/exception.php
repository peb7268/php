<?php

namespace Framework\Cache
{
    use Framework\Core as Core;
    
    class Exception extends Core\Exception
    {
        
    }
}

