<?php

namespace Framework\View\Exception
{
    use Framework\View as View;
    
    class Syntax extends View\Exception
    {
        
    }
}