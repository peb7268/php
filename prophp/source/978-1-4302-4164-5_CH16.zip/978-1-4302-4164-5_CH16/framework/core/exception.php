<?php

namespace Framework\Core
{
    class Exception extends \Exception
    {
        
    }
}