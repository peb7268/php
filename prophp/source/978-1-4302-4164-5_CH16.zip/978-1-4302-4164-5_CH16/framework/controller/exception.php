<?php

namespace Framework\Controller
{
    use Framework\Core as Core;
    
    class Exception extends Core\Exception
    {
    
    }
}