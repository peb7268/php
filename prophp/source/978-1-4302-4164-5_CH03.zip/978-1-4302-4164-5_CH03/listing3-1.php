<?php

class Car
{
    public $color;
    public $model;
}

$car = new Car();
$car->color = "blue";
$car->model = "b-class";