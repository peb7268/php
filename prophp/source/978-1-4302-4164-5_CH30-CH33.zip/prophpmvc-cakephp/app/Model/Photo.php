<?php

class Photo extends AppModel
{
    public $belongsTo = "User";
}