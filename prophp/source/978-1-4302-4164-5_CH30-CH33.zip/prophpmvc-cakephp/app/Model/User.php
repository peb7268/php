<?php

class User extends AppModel
{
    public $hasMany = "Photo";
}