<?php

namespace Framework\Database\Exception
{
    use Framework\Database as Database;
    
    class Service extends Database\Exception
    {
    
    }
}