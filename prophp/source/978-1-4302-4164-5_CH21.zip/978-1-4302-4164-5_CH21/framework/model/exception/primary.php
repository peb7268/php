<?php

namespace Framework\Model\Exception
{
    use Framework\Model as Model;
    
    class Primary extends Model\Exception
    {
        
    }
}