<?php

namespace Framework\Cache\Exception
{
    use Framework\Cache as Cache;
    
    class Service extends Cache\Exception
    {
    
    }
}