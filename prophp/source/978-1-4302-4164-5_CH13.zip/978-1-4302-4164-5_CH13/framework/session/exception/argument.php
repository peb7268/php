<?php

namespace Framework\Session\Exception
{
    use Framework\Core as Core;
    
    class Argument extends Core\Exception\Argument
    {
        
    }
}