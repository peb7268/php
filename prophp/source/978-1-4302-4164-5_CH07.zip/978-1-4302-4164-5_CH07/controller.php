<?php

namespace Framework
{
    use Framework\Base as Base;
    
    class Controller extends Base
    {
        /**
        * @readwrite
        */
        protected $_parameters;

    }

}