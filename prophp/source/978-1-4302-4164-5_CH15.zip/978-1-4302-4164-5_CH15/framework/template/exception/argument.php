<?php

namespace Framework\Template\Exception
{
    use Framework\Core as Core;
    
    class Argument extends Core\Exception\Argument
    {
        
    }
}