<?php

namespace Framework\Model\Exception
{
    use Framework\Model as Model;
    
    class Validation extends Model\Exception
    {
        
    }
}